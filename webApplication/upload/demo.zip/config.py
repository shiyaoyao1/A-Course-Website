#encoding:utf-8
DIALECT = 'MySQL'
DRIVER = 'pyMySQL'
USERNAME = 'dbuser'
PASSWORD = '123456'
HOST = 'localhost'
PORT = '3306'
DATABASE = 'test'
DB_URI = "{}+{}://{}:{}@{}:{}/{}?charset = utf8".format(DIALECT,DRIVER,USERNAME,PASSWORD,HOST,PORT,DATABASE)
SQLALCHEMY_TRACK_MODIFICATIONS = False
SQLALCHEMY_ECHO = True
