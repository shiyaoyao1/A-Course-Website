from sqlalchemydemo import *

if __name__ == '__main__':

    # 插入一条角色数据
    role1 = Role(name='admin')
    db.session.add(role1)

    # 再次插入一条数据
    role2 = Role(name='user')
    db.session.add(role2)
    db.session.commit()