from flask import Flask,url_for,redirect

app = Flask(__name__)

@app.route('/')
def hello_world():
    print("访问index()这个视图函数，函数名字为hello_world!")
    url1 = url_for('user_login')
    return redirect(url1)

@app.route('/login')
def user_login():
    return "这是用户登录页面，请登录！"

if __name__ == "__main__":
    app.run(debug=True)