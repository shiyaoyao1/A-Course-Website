from flask import Flask,render_template
from sqlalchemydemo import *

# app = Flask(__name__)

@app.route('/list_user')
def listUser():

    roleUser = Role.query.filter_by(name="user").first()

    users = User.query.filter_by(role_id = roleUser.id).all()

    return render_template("user.html",users = users)

if __name__ == "__main__":
    app.run(debug=True)