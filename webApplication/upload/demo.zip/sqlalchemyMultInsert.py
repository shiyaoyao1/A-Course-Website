from sqlalchemydemo import *

if __name__ == '__main__':

    # 一次性插入多条数据
    role1 = Role.query.filter_by(name="admin").first()
    role2 = Role.query.filter_by(name="user").first()
    user1 = User(name='wang',email='wang@163.com',pswd='123456',role_id=role1.id)
    user2 = User(name='zhang',email='zhang@189.com',pswd='201512',role_id=role2.id)
    user3 = User(name='chen',email='chen@126.com',pswd='987654',role_id=role2.id)
    user4 = User(name='zhou',email='zhou@163.com',pswd='456789',role_id=role1.id)
    db.session.add_all([user1,user2,user3,user4])
    db.session.commit()