import pymysql

conn = pymysql.connect(
    host='127.0.0.1',
    port=3306,
    user='dbuser',
    passwd='123456',
    db='biodatabase',
    charset='utf8'
)

cursor = conn.cursor()
sql = 'select * from student'
cursor.execute(sql)

results = cursor.fetchall()
for row in results:
    print("student's id is %s" % row[0])

cursor.close()
conn.close()