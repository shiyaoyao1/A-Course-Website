from flask import Flask,render_template
import pymysql

app = Flask(__name__)

conn = pymysql.connect(
    host='127.0.0.1',
    port=3306,
    user='dbuser',
    passwd='123456',
    db='biodatabase',
    charset='utf8'
)

cursor = conn.cursor()
sql = 'select * from student'
cursor.execute(sql)

results = cursor.fetchall()

@app.route('/')
def sqlselect():
    return render_template('sqlConnSelect.html',results = results)
    
cursor.close()
conn.close()

if __name__ == "__main__":
    app.run()