from flask import Flask,render_template

app = Flask(__name__)

#通过render_template返回网页（模板）
#如何给模板填充数据
@app.route('/')
def hellow_world():
    #通过render_template返回模板的名字，模板需放置在与该app同级的templates文件夹里
    name = "生物医学数据库BioDatabase"
    testList = [1,2,32,3,4,5,6]
    testDict = {
        'name': 'Flask微框架',
        'cno': 'A2060700'
    }
    return render_template('index.html',
                            name = name, 
                            testList = testList, 
                            testDict = testDict)
    

if __name__ == "__main__":
    app.run(debug=True)