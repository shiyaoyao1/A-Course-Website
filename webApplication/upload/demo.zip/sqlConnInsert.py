from flask import Flask,render_template
import pymysql

app = Flask(__name__)

conn = pymysql.connect(
    host='127.0.0.1',
    port=3306,
    user='dbuser',
    passwd='123456',
    db='biodatabase',
    charset='utf8'
)

cursor = conn.cursor()
try:
    sqlInsert = "insert into student(Sno,Sname,Ssex,Sage,Sdept) values ('20121527','mark','男','22','BI')"
    cursor.execute(sqlInsert)
    conn.commit()
except Exception as e:
    print(e)
    conn.rollback()
    cursor.close()
    conn.close()

@app.route('/')
def sqlselect():
    return "test"

if __name__ == "__main__":
    app.run()