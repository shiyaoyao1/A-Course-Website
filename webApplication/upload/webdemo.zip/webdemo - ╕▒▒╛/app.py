from flask import Flask,render_template,request
from biodatabase import *

@app.route('/')
def index():
    articles = Articles.query.order_by(Articles.id)[-2:]
    return render_template('index.html',articles = articles)

@app.route('/showaddarticle')
def showAddArticle():
    return render_template('addArticle.html')


@app.route('/addarticle',methods = ['POST', 'GET'])
def addArticle():
    if request.method == 'POST':
        # title = request.form['Title']
        time = request.form['Time']
        content = request.form['Content']
        print(time,content)
        article = Articles(title = request.form['Title'],time = time,content = content)
        db.session.add(article)
        db.session.commit()
    return "添加成功"

@app.route('/syllabus')
def showSyllabus():
    return render_template('syllabus.html')

if __name__ == "__main__":
    app.run(debug = True)